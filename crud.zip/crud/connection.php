<?php


$username = "root";
$password = "";
$server = 'localhost';
$db = 'crudoperationdb';


$con = mysqli_connect($server,$username,$password,$db);

if($con)
{

    ?>

    <script>
        alert('connection successfull');
    </script>

    <?php
    // echo "connection successfull";
} else {
    // echo "not Connected";

    die("no connection". mysqli_connect_error());
    
}

?>