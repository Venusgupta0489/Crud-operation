<?php

include 'connection.php';


$id = $_GET['id']; 

$deletequery = "DELETE FROM contactform  where id= $id";

$query = mysqli_query($con,$deletequery);

if($query){
    ?>
    <script>
        alert("deleted successfully");
    </script>
    <?php
} else{
    ?>
      <script>
        alert("not deleted successfully");
    </script>
    <?php
}
 
header('location:display.php');

?>