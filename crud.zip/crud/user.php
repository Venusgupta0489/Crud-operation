<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
 

<div class="container register">
    <div class="row">
        <div class="col-md-3 register-left">
            <h3>Welcom</h3>
            <p>Please Fill All The Details</p>
            <a href="display.php">Check Form</a>
        </div>

        <div class="col-md-9 register-right">
            <div class="tab-content" id="register-right">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab"
                >
            
            <h3 class="register-heading">Apply For Company Placement</h3>
        
        <form action="" method="POST">
        <div class="row register-form">
            <div class="col-md-6">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="enter your name" name="user" value="" required/>
                </div>

                <div class="form-group">
                    <input type="tel" class="form-control" placeholder="mobile number" name="mobile" required\>
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Any refrence" name="refer" required\>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="enter your qualification" name="degree" value="" required/>
                </div>

                <div class="form-group">
                    <input type="email" class="form-control" placeholder="email id" name="email" required\>
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" placeholder="prefered language" name="lang" required\>
                </div>

                <input type="submit" class="btnRegister" name="submit" value="register">
            </div>
        </div>

       

        </form>
        
        </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

<?php

include 'connection.php';


  if(isset($_POST['submit']))
{    
    $user = $_POST['user'];
    $degree = $_POST['degree'];
    $mobile = $_POST['mobile'];

    $email = $_POST['email'];
     $refer = $_POST['refer'];
     $lang = $_POST['lang'];


  $insertquery = "insert into contactform(user,degree,mobile,email,refer,lang) values('$user','$degree','$mobile','$email','$refer','$lang')";

      $con = mysqli_query($con,$insertquery);

  if($con){
         ?>
        <script>
           alert("data inserted properly");
        </script>
       <?php
    } else{

         ?>
    <script>
         alert("data not inserted ");
    </script>
      <?php

    }

 }

?>