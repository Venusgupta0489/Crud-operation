<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login-style.css">
</head>
<body>
<div class="center">
    <h1>Login</h1>
    <div class="form">
        <input type="text" name="" class="textfield" placeholder="Email ID">
        <input type="password" name="" class="textfield" placeholder="Password"> 
        <div class="forgetpass"><a href="#" class="link" onclick="message()">Forget Password</a></div>
   <input type="submit" name="" value="Login" class="btn" >
   <div class="signup">New Membera <a href="#" class="link">SignUp</a></div>
    </div>
</div>    

<script>
    function message() {
        alert("try to remmeber password");
    }
</script>
</body>
</html> -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/registration.css">
   
    <title>Registration</title>
</head>
<body>


<?php
include ('connection.php');

if(isset($_POST['submit'])){
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $mobile = mysqli_real_escape_string($con,$_POST['mobile']);
    $password =mysqli_real_escape_string($con,$_POST['password']);
    $cpassword =mysqli_real_escape_string($con,$_POST['cpassword']);

$pass = password_hash($password,PASSWORD_BCRYPT);
$cpass = password_hash($password,PASSWORD_BCRYPT);


$emailQuery = "SELECT * FROM registration WHERE email='$email' ";
$query = mysqli_query($con,$emailQuery);

$emailcount = mysqli_num_rows($query);

if($emailcount>0){
    echo "email already exists";
}else{
    if($password === $cpassword){

$insertquery= "INSERT INTO registration( username, email, mobile, password, cpassword) VALUES('$username','$email','$mobile','$pass','$cpass')";

$iquery = mysqli_query($con,$insertquery);

            if($con){           
            ?>

                <script>
               alert('Registration successfull');
              </script>

                <?php
   
                    } else {
                    ?>
                    <script>
                       alert("No Inserted");
                   </script>
                <?php        
}

                }else{
                    ?>
                    <script>
                       alert("No Inserted");
                   </script>
                <?php    
                }

            }
        }
?>
    <div class="card bg-light">
        <article class="card-body mx-auto" style="max-width:400px;">
    
    <h4 class="card-title mt-3 text-center">Create Account</h4>
    <p class="text-center">Lets Get Started</p>
    <p>
        <a href="" class="btn btn-block btn-gmail">  <i class="fa fa-google"></i>Login via gmail</a>
        <a href="" class="btn btn-block btn-facebook">  <i class="fa fa-facebook"></i>Login Via Facebook</a>

    </p>
    <p class="divider-text">
        <span class="bg-light">OR</span>
    </p>

    <form action="" method="POST">
        <!--Form Group  -->
        <div class="form-group input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fa fa-user"></i></span>
            </div>
            <input type="text" name="username" class="form-control" placeholder="Full Name" required>
                 </div>


                    <!--Form Group  -->
        <div class="form-group input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fa fa-envelope"></i></span>
            </div>
            <input type="email" name="email" class="form-control" placeholder="Email address" required>
                 </div>

        <!--form group  -->
        <div class="form-group input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"> <i class="fa fa-phone"></i></span>
            </div>
            <input type="number" name="mobile" class="form-control" placeholder="Mobile Number" required>
        </div>

        <!-- form group -->
        <div class="form-group input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"> <i class="fa fa-lock"></i></span>
            </div>
            <input type="password" name="password" class="form-control" placeholder="create password" required>
          
        </div>
            <!-- .Form group -->

            <div class="form-group input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"> <i class="fa fa-lock"></i></span>
            </div>
            <input type="password" name="cpassword" class="form-control" placeholder="Repeat password" required>
        </div>
        <!-- Form Group -->

        <div class="form-group">
            <button type="submit" name="submit" class="btn btn-primary btn-block">Create Account </button>
        </div>

        <!-- form group -->
        <p class="text-center">Have An account <a href="login.php">Log in</a></p>
        
    </form>

</article>
    </div>


   <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
</body>
</html>